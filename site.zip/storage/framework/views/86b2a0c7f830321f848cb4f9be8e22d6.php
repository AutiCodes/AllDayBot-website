<?php echo $__env->make("layout.head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="log_container">
        
    <div class="container">
        <h1>Log Activity Lists</h1>
        <table class="table table-bordered">
            <tr>
                <th>No</th>
                <th>Subject</th>
                <th>URL</th>
                <th>Method</th>
                <th>Ip</th>
                <th width="300px">User Agent</th>
                <th>username</th>
            </tr>

                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key); ?></td>
                    <td><?php echo e($log->subject); ?></td>
                    <td class="text-success"><?php echo e($log->url); ?></td>
                    <td><label class="label label-info"><?php echo e($log->method); ?></label></td>
                    <td class="text-warning"><?php echo e($log->IP); ?></td>
                    <td class="text-danger"><?php echo e($log->agent); ?></td>
                    <td><?php echo e($log->username); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<style>
.log_container {
    padding-top: 7%;
    padding-bottom: 7%;
}
</style>
</html>
<?php /**PATH C:\Users\k_der\developing\Github\AllDayBot-website\resources\views/system/logs.blade.php ENDPATH**/ ?>