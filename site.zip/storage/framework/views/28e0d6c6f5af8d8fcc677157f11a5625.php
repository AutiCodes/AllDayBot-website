<footer class="footer mt-auto py-3 bg-primary">
    <div class="container">
        <center>
            <p class="text-white">&copy; <?php echo date("Y"); ?> AllDayTechAndGaming - In development door KelvinCodes</p>
        </center>
    </div>
 </footer>


<style>
    html {
  position: relative;
  min-height: 100%;
}
body {
  margin-bottom: 60px; /* Margin bottom by footer height */
}
.footer {
    position: fixed;
    height: 7%;
    bottom: 0;
    width: 100%;
}
</style>
<?php /**PATH C:\Users\k_der\developing\Github\AllDayBot-website\resources\views/layout/footer.blade.php ENDPATH**/ ?>