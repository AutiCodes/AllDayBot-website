
<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br>
<main class="login-form">
  <div class="cotainer">
      <div class="row justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header">Wijzig je wachtwoord</div>
                  <div class="card-body">
  
                      <form action="/post-wachtwoord-wijzigen" method="POST">
                          <?php echo csrf_field(); ?>

                          <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php elseif(session('error')): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>

                          <div class="form-group row">
                              <label for="password" class="col-md-4 col-form-label text-md-right">Wachtwoord</label>
                              <div class="col-md-6">
                                  <input type="password" id="password" class="form-control" name="password" required>
                                  <?php if($errors->has('password')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                  <?php endif; ?>

                                  <input type="checkbox" onclick="first_password()">Laat het wachtwoord zien

                              </div>
                          </div>
  
                          <div class="form-group row">
                              <label for="password_second" class="col-md-4 col-form-label text-md-right">Wachtwoord opnieuw invoeren</label>
                              <div class="col-md-6">
                                  <input type="password" id="password_second" class="form-control" name="password_second" required>
                                  <?php if($errors->has('password')): ?>
                                      <span class="text-danger"><?php echo e($errors->first('password_second')); ?></span>
                                  <?php endif; ?>

                              </div>

                          </div>

  
                          <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Wachtwoord wijzigen
                              </button>
                          </div>
                      </form>
                        
                  </div>
              </div>
          </div>
      </div>
  </div>
</main>


<script>
function first_password() {
    var x = document.getElementById("password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

</script><?php /**PATH C:\Users\k_der\developing\Github\AllDayBot-website\resources\views/auth/password_reset.blade.php ENDPATH**/ ?>