<?php


$data = array(
  "kelvin" => 23
);

echo $data["kelvin"];